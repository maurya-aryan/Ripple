//import { nthRt, isEven } from "johnfo-temp1";
import { nthRt, isEven } from "./index.js";

console.log(nthRt(2));

console.log(isEven(2));

