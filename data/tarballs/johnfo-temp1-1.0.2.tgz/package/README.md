# This is a sample package

See https://dev.to/codesphere/how-to-publish-your-first-npm-package-in-minutes-16in