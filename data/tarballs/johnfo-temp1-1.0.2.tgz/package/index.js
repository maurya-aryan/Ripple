import isOdd from "is-odd";

export function nthRt(n) {
     return n ** (1 / n);
}
export function isEven(n) {
     return !isOdd(n);
}

