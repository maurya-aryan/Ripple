const _true = require("true");
const _false = require("false");
const isNumber = require("is-number");
const isOdd = require("is-odd");
const isEven = require("is-even");

module.exports = function(val, checkIfTheNumberIsEvenAndThenReturnABooleanBasedOnIfItIsEvenOrNot = false, checkIfTheNumberIsOddAndThenReturnABooleanBasedOnIfItIsEvenOrNot = false) {
	if (checkIfTheNumberIsEvenAndThenReturnABooleanBasedOnIfItIsEvenOrNot === _true()) {
		if (checkIfTheNumberIsOddAndThenReturnABooleanBasedOnIfItIsEvenOrNot === _true()) {
			throw new Error("Number can't be even and odd at the same time.");
		}
		if (isNumber(val) === _true()) {
			return isEven(parseInt(val));
		}
	}
	if (checkIfTheNumberIsOddAndThenReturnABooleanBasedOnIfItIsEvenOrNot === _true()) {
		if (checkIfTheNumberIsEvenAndThenReturnABooleanBasedOnIfItIsEvenOrNot === _true()) {
			throw new Error("Number can't be even and odd at the same time.");
		}
		if (isNumber(val) === _true()) {
			return isOdd(parseInt(val));
		}
	}
	if (isNumber(val) === _true()) {
		return parseInt(val);
	}
	if (val === _true()) {
		return true;
	}
	if (val === _false()) {
		return false;
	}
	else {
		return val;
	}
}
