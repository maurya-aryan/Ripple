# return-js

### The practical way to return values

### How to use

Just simply include the package in your project using `npm i @_immo/return` or `yarn add @_immo/return` and use the package as follows

```js
const _return = require("@_immo/return");
const a = 1;
function() {
	_return(a);
}
```
